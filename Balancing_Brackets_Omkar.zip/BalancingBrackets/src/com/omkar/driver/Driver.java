package com.omkar.driver;

import com.omkar.service.BalancingBrackets;

public class Driver {

	public static void main(String[] args) {
		BalancingBrackets balancingBrackets = new BalancingBrackets();
        String bracketExpression = "([[{}]])";
        
        Boolean result ; 
        
        result = balancingBrackets.checkingBracketBalanced(bracketExpression);
        
        if(result)
        	System.out.println("The entered string has Balanced Brackets");
        else 
        	System.out.println("The entered string do not contain Balanced Brackets");
	}

}
