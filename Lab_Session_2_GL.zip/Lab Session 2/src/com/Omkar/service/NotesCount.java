package com.Omkar.service;

public class NotesCount {
	public void notesCountImplementation(int[] notes , int amount) {
		int[] noteCounter = new int[notes.length];
		
		for(int i=0; i<notes.length; i++) {
			if(amount >= notes[i]) {
				noteCounter[i] = amount / notes[i];
				amount = amount - noteCounter[i] * notes[i];
			}
		}
		System.out.println("Your payment approach in order to give min no of notes will be");
		for(int j=0; j<notes.length ; j++) {
			if(noteCounter[j] != 0) {
				System.out.println(notes[j]+ " : " +noteCounter[j]);
			}
		}
	}

}
